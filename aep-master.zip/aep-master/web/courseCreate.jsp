<%@page contentType="text/html" pageEncoding="UTF-8"%> 
<%@page import="java.sql.*"%>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Course Management</title>
    <style>
  body {
    font-family: Arial, sans-serif;
    background-color: #f8f9fa;
    margin: 0;
    padding: 0;
}

.container {
    max-width: 1200px;
    margin: 30px auto;
    background: white;
    padding: 20px;
    border-radius: 8px;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
}

h1, h2 {
    text-align: center;
    color: #3a5a40;
}

form {
    max-width: 600px;
    margin: 20px auto;
    padding: 20px;
    background-color: #fff;
    border: 1px solid #ddd;
    border-radius: 8px;
}

label {
    font-weight: bold;
    display: block;
    margin-top: 10px;
}

input, textarea, select, button {
    width: 100%;
    padding: 10px;
    margin-top: 8px;
    border: 1px solid #ddd;
    border-radius: 4px;
}

button {
    background-color: #6a994e;
    color: white;
    cursor: pointer;
}

button:hover {
    background-color: #545454;
}

table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 20px;
}

th, td {
    border: 1px solid #ddd;
    padding: 10px;
    text-align: center;
}

th {
    background-color: #f1f1f1;
}

.button-group {
    display: flex;
    justify-content: center; 
    gap: 5px; 
}
.button-group form {
    margin: 0;
    padding: 0;
    border: none; 
    background: none; 
    display: flex; 
    align-items: center; 
}

.small-button {
    padding: 6px 12px; 
    font-size: 12px; 
    border: none;
    border-radius: 4px;
    background-color: #69747C; 
    color: white;
    cursor: pointer;
    width: auto; 
}

.small-button:hover {
    background-color: #82ABA1; 
}

.delete-button {
    background-color: #785964; 
}

.delete-button:hover {
    background-color: #BDEDE0; 
}

    </style>
</head>
<body>
    <div class="container">
        <h1>Course Management Dashboard</h1>

        <!-- Section: Create a Course -->
        <h2>Create Course</h2>
        <form action="CourseServlet" method="POST">
            <input type="hidden" name="action" value="create">
            <label for="courseCode">Course Code:</label>
            <input type="text" id="courseCode" name="courseCode" placeholder="e.g., CST8288" required>
            
            <label for="courseName">Course Name:</label>
            <input type="text" id="courseName" name="courseName" placeholder="e.g., Object Oriented Programming" required>
            
            <label for="semester">Semester:</label>
            <input type="text" id="semester" name="semester" placeholder="e.g., Fall 2024" required>
            
            <label for="instructor">Instructor:</label>
            <input type="text" id="instructor" name="instructor" placeholder="e.g., Dr. John Smith" required>
            
            <label for="schoolName">School Name:</label>
            <input type="text" id="schoolName" name="schoolName" placeholder="e.g., Algonquin College" required>
            
            <label for="schoolAddress">School Address:</label>
            <input type="text" id="schoolAddress" name="schoolAddress" placeholder="e.g., 1385 Woodroffe Ave, Ottawa, ON" required>
            
            <label for="description">Description:</label>
            <textarea id="description" name="description" rows="4" placeholder="e.g., This course focuses on design patterns and advanced OOP concepts."></textarea>
            
            <button type="submit">Create Course</button>
        </form>

        <!-- Section: Search for Courses -->
        <h2>Search Courses</h2>
        <form action="CourseServlet" method="GET">
            <input type="hidden" name="action" value="search">
            
            <label for="searchCriteria">Search Criteria:</label>
            <select id="searchCriteria" name="searchCriteria" required>
                <option value="course_code">Course Code</option>
                <option value="course_name">Course Name</option>
                <option value="school_name">School Name</option>
                <option value="semester">Semester</option>
            </select>
            
            <label for="searchValue">Search Value:</label>
            <input type="text" id="searchValue" name="searchValue" placeholder="e.g., CST8288" required>
            
            <button type="submit">Search</button>
        </form>

        <!-- Section: Display Existing Courses -->
        <h2>Existing Courses</h2>
        <table>
            <thead>
                <tr>
                    <th>Course Code</th>
                    <th>Course Name</th>
                    <th>Semester</th>
                    <th>Instructor</th>
                    <th>School Name</th>
                    <th>School Address</th>
                    <th>Description</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <%
                    String jdbcURL = "jdbc:mysql://localhost:3306/aep";
                    String dbUser = "root";
                    String dbPassword = "Rhian522020@";

                    try (Connection conn = DriverManager.getConnection(jdbcURL, dbUser, dbPassword);
                         Statement stmt = conn.createStatement();
                         ResultSet rs = stmt.executeQuery("SELECT * FROM Courses")) {

                        while (rs.next()) {
                %>
                <tr>
                    <td><%= rs.getString("course_code") %></td>
                    <td><%= rs.getString("course_name") %></td>
                    <td><%= rs.getString("semester") %></td>
                    <td><%= rs.getString("instructor") %></td>
                    <td><%= rs.getString("school_name") %></td>
                    <td><%= rs.getString("school_address") %></td>
                    <td><%= rs.getString("description") %></td>
                    <td class="action-buttons">
                    <div class="button-group">
                        <form action="CourseServlet" method="POST" class="inline-form">
                            <input type="hidden" name="action" value="edit">
                            <input type="hidden" name="courseId" value="<%= rs.getInt("course_id") %>">
                            <button type="submit" class="small-button">Edit</button>
                        </form>
                        <form action="CourseServlet" method="POST" class="inline-form">
                            <input type="hidden" name="action" value="delete">
                            <input type="hidden" name="courseId" value="<%= rs.getInt("course_id") %>">
                            <button type="submit" class="small-button delete-button">Delete</button>
                        </form>
                    </div>

                    </td>
                </tr>
                <%
                        }
                    } catch (SQLException e) {
                        out.println("<tr><td colspan='8'>Error fetching courses: " + e.getMessage() + "</td></tr>");
                    }
                %>
            </tbody>
        </table>
        <div style="text-align: center; margin-top: 20px;">
            <form action="dashboard.jsp" method="GET" style="border: none; padding: 0; margin: 0; background: none;">
                <button type="submit" style="background-color: #3a5a40; color: white; padding: 10px 20px; font-size: 16px; border: none; border-radius: 5px; cursor: pointer;">
                    Go Back to Dashboard
                </button>
            </form>
        </div>
    </div>
</body>
</html>
