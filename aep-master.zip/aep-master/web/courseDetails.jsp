<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@page import="models.AcademicCourse"%>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Course Details</title>
        <style>
            body { 
                font-family: Arial, sans-serif; 
                margin: 0; 
                padding: 0; 
                text-align: center; 
                background-color: #f4f4f4;
            }
            .container {
                max-width: 600px;
                margin: 50px auto;
                padding: 20px;
                background: #fff;
                border: 1px solid #ddd;
                border-radius: 8px;
                box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            }
            h1 {
                color: #74121d;
            }
            table {
                width: 100%;
                border-collapse: collapse;
                margin: 20px 0;
            }
            table th, table td {
                text-align: left;
                padding: 10px;
                border: 1px solid #ddd;
            }
            table th {
                background: #f4f4f4;
            }
            .back-button {
                display: inline-block;
                margin: 10px;
                padding: 10px 20px;
                background-color: #74121d;
                color: white;
                text-decoration: none;
                border-radius: 4px;
            }
            .back-button:hover {
                background-color: #83c5be;
            }
        </style>
    </head>
    <body>
        <div class="container">
            <h1>Course Updated Successfully</h1>

            <%
                // Retrieve the AcademicCourse object passed by the servlet
                AcademicCourse course = (AcademicCourse) request.getAttribute("course");
                if (course == null) {
                    out.println("<p>Error: No course details available.</p>");
                    out.println("<a href='courseCreate.jsp' class='back-button'>Go Back to Course Management</a>");
                    return;
                }
            %>

            <table>
                <tr>
                    <th>Course Code</th>
                    <td><%= course.getCourseCode() %></td>
                </tr>
                <tr>
                    <th>Course Name</th>
                    <td><%= course.getCourseTitle() %></td>
                </tr>
                <tr>
                    <th>Semester</th>
                    <td><%= course.getSemester() %></td>
                </tr>
                <tr>
                    <th>Instructor</th>
                    <td><%= course.getInstructor() %></td>
                </tr>
                <tr>
                    <th>School Name</th>
                    <td><%= course.getInstitutionName() %></td>
                </tr>
                <tr>
                    <th>School Address</th>
                    <td><%= course.getSchoolAddress() %></td>
                </tr>
                <tr>
                    <th>Description</th>
                    <td><%= course.getDescription() %></td>
                </tr>
            </table>

            <a href="dashboard.jsp" class="back-button">Go Back to Dashboard</a>
            <a href="courseCreate.jsp" class="back-button">Go Back to Course Management</a>
        </div>
    </body>
</html>