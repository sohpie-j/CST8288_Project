<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="models.AcademicInstitution" %>
<%
    AcademicInstitution institution = (AcademicInstitution) request.getAttribute("institution");
%>
<!DOCTYPE html>
<html>
<head>
    <title>Institution Profile</title>
    <link rel="stylesheet" type="text/css" href="style.css">

</head>
<body>
    <div class="container">
    <h1>Institution Profile</h1>
    <form action="updateInstitutionProfileServlet" method="post">
        <label>Email:</label>
        <input type="email" name="email" value="<%= institution.getEmail() %>" readonly><br>
        <label>Password:</label>
        <input type="text" name="password" value="<%= institution.getPassword() %>"><br>
        <label>Institution Name:</label>
        <input type="text" name="institutionName" value="<%= institution.getInstitutionName() %>" readonly><br>
        <label>Address:</label>
        <textarea name="address"><%= institution.getAddress() %></textarea><br>
        <label>Courses Offered:</label>
        <textarea name="coursesOffered"><%= institution.getCoursesOffered() %></textarea><br>
        <button type="submit">Update</button>
    </form>
    </div>
</body>
</html>