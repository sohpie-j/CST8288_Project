<!DOCTYPE html>
<html>
<head>
    <title>Register as an Academic Institution</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
            text-align: center;
        }
        h1 {
            color: #4CAF50;
        }
        form {
            max-width: 400px;
            margin: auto;
            text-align: left;
        }
        label {
            font-weight: bold;
        }
        input[type="email"], input[type="password"], select {
            width: 100%;
            padding: 10px;
            margin: 10px 0 20px 0;
            border: 1px solid #ddd;
            border-radius: 4px;
            box-sizing: border-box;
        }
        button {
            background-color: #4CAF50;
            color: white;
            padding: 10px 15px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        button:hover {
            background-color: #45a049;
        }
    </style>
</head>
<body>
    <h1>Register as an Academic Institution</h1>
    <form action="registerInstitutionServlet" method="post">
        <label>Email:</label>
        <input type="email" name="email" required><br>
        <label>Password:</label>
        <input type="password" name="password" required><br>
        <label>Institution Name:</label>
        <select name="institutionName" required>
            <option value="" disabled selected>Select Institution</option>
            <option value="University of Ottawa">University of Ottawa</option>
            <option value="Algonquin College">Algonquin College</option>
            <option value="Carleton University">Carleton University</option>
        </select><br>
        <button type="submit">Register</button>
    </form>
</body>
</html>
