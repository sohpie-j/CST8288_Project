<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="models.AcademicProfessional" %>
<%
    AcademicProfessional professional = (AcademicProfessional) request.getAttribute("professional");
%>
<!DOCTYPE html>
<html>
<head>
    <title>Professional Profile</title>
    <link rel="stylesheet" type="text/css" href="style.css">

</head>
<body>
    <div class="container">
    <h1>Professional Profile</h1>
    <form action="updateProfessionalProfileServlet" method="post">
        <label>Name:</label>
        <input type="text" name="name" value="<%= professional.getName() %>" readonly><br>
        <label>Email:</label>
        <input type="email" name="email" value="<%= professional.getEmail() %>" readonly><br>
        <label>Password:</label>
        <input type="text" name="password" value="<%= professional.getPassword() %>"><br>
        <label>Current Institution:</label>
        <input type="text" name="currentInstitution" value="<%= professional.getCurrentInstitution() %>"><br>
        <label>Academic Position:</label>
        <input type="text" name="academicPosition" value="<%= professional.getAcademicPosition() %>"><br>
        <label>Education Background:</label>
        <textarea name="educationBackground"><%= professional.getEducationBackground() %></textarea><br>
        <label>Area of Expertise:</label>
        <textarea name="areaOfExpertise"><%= professional.getAreaOfExpertise() %></textarea><br>
        <button type="submit">Update</button>
    </form>
    </div>
</body>
</html>
