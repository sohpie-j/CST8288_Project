<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@page import="java.util.List"%>
<%@page import="models.AcademicCourse"%>
<%@page import="javax.servlet.http.HttpSession"%>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Search Results</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f4f4f9;
            margin: 0;
            padding: 0;
        }
        .container {
            max-width: 1200px;
            margin: 30px auto;
            padding: 20px;
            background-color: #ffffff;
            border-radius: 8px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            text-align: center;
        }
        h1 {
            font-size: 2rem;
            color: #4CAF50;
            margin-bottom: 20px;
        }
        .message {
            font-size: 1rem;
            color: #333;
            margin: 10px 0;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        th, td {
            padding: 15px;
            text-align: center;
        }
        th {
            background-color: #4CAF50;
            color: white;
            text-transform: uppercase;
        }
        tr:nth-child(even) {
            background-color: #f9f9f9;
        }
        tr:hover {
            background-color: #f1f1f1;
        }
        td {
            border-bottom: 1px solid #ddd;
        }
        .no-results {
            margin-top: 20px;
            font-size: 1.2rem;
            color: #ff6f61;
        }
        .back-button {
            display: inline-block;
            margin-top: 20px;
            padding: 10px 20px;
            text-decoration: none;
            background-color: #4CAF50;
            color: white;
            border-radius: 5px;
            font-size: 1rem;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        .back-button:hover {
            background-color: #45a049;
            box-shadow: 0 6px 10px rgba(0, 0, 0, 0.15);
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Search Results</h1>

        <% 
            // Fetch the list of search results and message from request
            List<AcademicCourse> searchResults = (List<AcademicCourse>) request.getAttribute("searchResults");
            String message = (String) request.getAttribute("message");

           
            Boolean isAcademicProfessionalObj = (Boolean) session.getAttribute("isAcademicProfessional");
            Boolean isAcademicInstitutionObj = (Boolean) session.getAttribute("isAcademicInstitution");

            // Default to false if session attributes are null
            boolean isAcademicProfessional = isAcademicProfessionalObj != null && isAcademicProfessionalObj;
            boolean isAcademicInstitution = isAcademicInstitutionObj != null && isAcademicInstitutionObj;
        %>

        <p class="message"><%= message != null ? message : "" %></p>
        
        <% if (searchResults != null && !searchResults.isEmpty()) { %>
            <table>
                <thead>
                    <tr>
                        <th>Course Code</th>
                        <th>Course Name</th>
                        <th>Semester</th>
                        <th>Instructor</th>
                        <th>School Name</th>
                        <th>School Address</th>
                        <th>Description</th>
                        <th>Actions</th>
                        <% if (isAcademicProfessional) { %>
                            <th>Request to Teach</th> 
                            <th>Application Status</th> 
                        <% } %>
                    </tr>
                </thead>
                <tbody>
                    <% for (AcademicCourse course : searchResults) { %>
                    <tr>
                        <td><%= course.getCourseCode() %></td>
                        <td><%= course.getCourseTitle() %></td>
                        <td><%= course.getSemester() %></td>
                        <td><%= course.getInstructor() %></td>
                        <td><%= course.getInstitutionName() %></td>
                        <td><%= course.getSchoolAddress() %></td>
                        <td><%= course.getDescription() %></td>
                        <td>
                            <!-- View Details Link -->
                            <a href="courseDetails.jsp?courseCode=<%= course.getCourseCode() %>" class="back-button">View Details</a>
                            
                        </td>  
                        <% if (isAcademicProfessional) { %>
                            <td>
                                <!-- Request to Teach Link -->
                                <a href="ApplyTeachRequest.jsp?courseCode=<%= course.getCourseCode() %>" class="back-button">Request to Teach</a>
                            </td>
                            <td>
                                <!-- Application Status Link -->
                                <a href="viewReply.jsp?courseCode=<%= course.getCourseCode() %>" class="back-button">Application Status</a>
                            </td>
                        <% } %>
                    </tr>
                    <% } %>
                </tbody>
            </table>
        <% } else { %>
            <div class="no-results">No results found for your search criteria.</div>
        <% } %>

        <a href="dashboard.jsp" class="back-button">Go Back to Dashboard</a>
    </div>
</body>
</html>
