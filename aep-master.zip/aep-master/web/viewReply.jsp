<%-- 
    Document   : viewReply
    Created on : Dec 1, 2024, 2:03:39 AM
    Author     : yuand
--%>


<%@ page contentType="text/html; charset=UTF-8" %>
<%@ page import="java.sql.*" %>
<%@ page import="dao.DBConnection" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Application Status</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f4f4f9;
            margin: 0;
            padding: 0;
        }
        .container {
            max-width: 600px;
            margin: 50px auto;
            padding: 20px;
            background-color: #ffffff;
            border-radius: 8px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            text-align: center;
        }
        h1 {
            font-size: 2rem;
            color: #4CAF50;
            margin-bottom: 20px;
        }
        p {
            font-size: 1.2rem;
            color: #333;
            margin: 20px 0;
        }
        .back-button {
            display: inline-block;
            padding: 10px 20px;
            text-decoration: none;
            background-color: #4CAF50;
            color: white;
            border-radius: 5px;
            font-size: 1rem;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        .back-button:hover {
            background-color: #45a049;
            box-shadow: 0 6px 10px rgba(0, 0, 0, 0.15);
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Application Status</h1>

        <%
            Connection conn = null;
            PreparedStatement pstmt = null;
            ResultSet rs = null;
            String replyMessage = "";
            String status = "";

            try {
                conn = DBConnection.getConnection();
                //Class.forName("com.mysql.cj.jdbc.Driver");
                //conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/aep", "root", "Rhian522020@");
                String sql = "SELECT * FROM teach_requests WHERE course_id = ?";
                pstmt = conn.prepareStatement(sql);
                pstmt.setString(1, request.getParameter("courseCode"));
                //pstmt.setInt(1, Integer.parseInt(request.getParameter("courseCode")));
                System.out.println(request.getParameter("courseCode"));
                rs = pstmt.executeQuery();

                if (rs.next()) {
                    replyMessage = rs.getString("reply_message");
                    status = rs.getString("status");
                }
            } catch (Exception e) {
                e.printStackTrace();
            } finally {
                try { if (rs != null) rs.close(); } catch (SQLException e) { e.printStackTrace(); }
                try { if (pstmt != null) pstmt.close(); } catch (SQLException e) { e.printStackTrace(); }
                try { if (conn != null) conn.close(); } catch (SQLException e) { e.printStackTrace(); }
            }
        %>

        <p>Your application has been processed.</p>
        <p>Status: <%= status %></p>
        <p>Reply from academic institution:</p>
        <p><%= replyMessage %></p>

        <a href="dashboard.jsp" class="back-button">Back to Dashboard</a>
    </div>
</body>
</html>