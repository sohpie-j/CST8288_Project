<%-- 
    Document   : createCourse
    Created on : Nov 26, 2024, 3:36:06 PM
    Author     : kajan
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@page import="models.AcademicCourse"%>
<%
    AcademicCourse course = (AcademicCourse) request.getAttribute("course");
%>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Create Course</title>
        <style>
body {
    font-family: Arial, sans-serif;
    margin: 0;
    padding: 0;
    background-color: #f8f9fa;
    text-align: center;
}

form {
    max-width: 500px; /* Adjusted for a balanced width */
    margin: 50px auto;
    padding: 20px;
    border: 1px solid #ddd;
    border-radius: 8px;
    background-color: #fff;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1); /* Add subtle shadow */
}

label {
    font-weight: bold;
    display: block;
    margin-top: 15px;
    text-align: left; /* Align labels to the left */
}

input, button, textarea {
    width: calc(100% - 24px); /* Ensure proper alignment inside the form */
    padding: 12px;
    margin: 10px 0;
    border: 1px solid #ddd;
    border-radius: 4px;
    box-sizing: border-box; /* Ensures padding is included in total width */
}

input, textarea {
    font-size: 14px;
    font-family: Arial, sans-serif;
}

textarea {
    height: 100px; /* Adjusted height */
    resize: none; /* Disable resizing for consistency */
}

button {
    background-color: #4CAF50;
    color: white;
    font-size: 16px;
    cursor: pointer;
    border: none; /* Remove default border */
    transition: background-color 0.3s ease;
}

button:hover {
    background-color: #45a049;
}


       </style>
    </head>
<!--    <body>
        <div class="container">
            <h1>Create/Search Course</h1>
            <form action="CourseServlet" method="POST">
                <input type="hidden" name="action" value="create">
                <div>
                    <label for="courseCode">Course Code:</label>
                    <input type="text" id="courseCode" name="courseCode" placeholder="e.g., ENG301">
                </div>
                <div>
                    <label for="courseName">Course Name:</label>
                    <input type="text" id="courseName" name="courseName" placeholder="e.g., Shakespearean Literature">
                </div>
                <div>
                    <label for="semester">Semester:</label>
                    <input type="text" id="semester" name="semester" placeholder="e.g., Fall 2024">
                </div>
                <div>
                    <label for="instructor">Instructor:</label>
                    <input type="text" id="instructor" name="instructor" placeholder="e.g., Prof. John Carter">
                </div>
                <div>
                    <label for="schoolName">School Name:</label>
                    <input type="text" id="schoolName" name="schoolName" placeholder="e.g., Arts Academy">
                </div>
                <div>
                    <label for="schoolAddress">School Address:</label>
                    <input type="text" id="schoolAddress" name="schoolAddress" placeholder="e.g., 789 Arts Blvd, Oxford, UK">
                </div>
                <div>
                    <label for="description">Description:</label>
                    <textarea id="description" name="description" rows="4" placeholder="e.g., Explores the works of William Shakespeare and their historical context."></textarea>
                </div>
                <a herf="searchResults.jsp"><button type="search">Search Course</button></a>
            </form>
        </div>
    </body>-->
<body>
    <h1>Update Course</h1>
    <form action="CourseServlet" method="POST">
        <input type="hidden" name="action" value="update">
        <input type="hidden" name="courseId" value="<%= course.getId() %>">

        <label for="courseCode">Course Code:</label>
        <input type="text" id="courseCode" name="courseCode" value="<%= course.getCourseCode() %>" required>

        <label for="courseName">Course Name:</label>
        <input type="text" id="courseName" name="courseName" value="<%= course.getCourseTitle() %>" required>

        <label for="semester">Semester:</label>
        <input type="text" id="semester" name="semester" value="<%= course.getSemester() %>" required>

        <label for="instructor">Instructor:</label>
        <input type="text" id="instructor" name="instructor" value="<%= course.getInstructor() %>" required>

        <label for="schoolName">School Name:</label>
        <input type="text" id="schoolName" name="schoolName" value="<%= course.getInstitutionName() %>" required>

        <label for="schoolAddress">School Address:</label>
        <input type="text" id="schoolAddress" name="schoolAddress" value="<%= course.getSchoolAddress() %>" required>

        <label for="description">Description:</label>
        <textarea id="description" name="description" rows="4"><%= course.getDescription() %></textarea>

        <button type="submit">Update Course</button>
    </form>
</body>
</html>
