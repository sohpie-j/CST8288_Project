<%@ page contentType="text/html; charset=UTF-8" %>

<!DOCTYPE html>
<html>
<head>
    <title>Complete Professional Profile</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 0; padding: 0; text-align: center; }
        form { max-width: 400px; margin: 50px auto; padding: 20px; border: 1px solid #ddd; border-radius: 8px; }
        label { font-weight: bold; display: block; margin-top: 15px; }
        input, button { width: 100%; padding: 10px; margin: 10px 0; border: 1px solid #ddd; border-radius: 4px; }
        button { background-color: #4CAF50; color: white; cursor: pointer; }
        button:hover { background-color: #45a049; }
    </style>
</head>
<body>
    <h1>Complete Your Professional Profile</h1>
    <form action="updateProfessionalProfileServlet" method="post">
    
    <input type="hidden" id="email" name="email" value="${professional.email}">
      
        
    <label for="educationBackground">Education Background:</label>
    <input type="text" id="educationBackground" name="educationBackground" required>
    
    <label for="areaOfExpertise">Area of Expertise:</label>
    <input type="text" id="areaOfExpertise" name="areaOfExpertise" required>
    
    <button type="submit">Submit</button>
</form>

</body>
</html>
