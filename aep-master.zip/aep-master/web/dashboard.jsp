<%@ page session="true" contentType="text/html; charset=UTF-8" %>
<%
    Object user = session.getAttribute("user");
    if (user == null) {
        response.sendRedirect("login.jsp");
        return;
    }
%>
<!DOCTYPE html>
<html>
<head>
    <title>Dashboard</title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
    <div class="container">
        <h1>Welcome to the Academic Exchange Platform</h1>
        <% if (user instanceof models.AcademicProfessional) { %>
            <p>Welcome, <strong><%= ((models.AcademicProfessional) user).getName() %>!</strong></p>
            <p>Your email: <%= ((models.AcademicProfessional) user).getEmail() %></p>
        <% } else if (user instanceof models.AcademicInstitution) { %>
            <p>Welcome, <strong><%= ((models.AcademicInstitution) user).getInstitutionName() %>!</strong></p>
            <p>Your email: <%= ((models.AcademicInstitution) user).getEmail() %></p>
        <% } %>
        <form action="logoutServlet" method="post">
            <button type="submit">Logout</button>
        </form>
        <form action="profileServlet" method="get">
            <button type="submit">View/Update Profile</button>
        </form>
        <% if (user instanceof models.AcademicProfessional) { %>
            <form action="courseCreate.jsp" method="get">
                <button type="submit">Course Management</button>
            </form>
        <% } else if (user instanceof models.AcademicInstitution) { %>
            
            <form action="courseCreate.jsp" method="get">
                <button type="submit">Course Management</button>
            </form>
            <form action="ManageAllRequests" method="get">
                <button type="submit">View All Teaching Request</button>
            </form>
        <% } %>
    </div>
</body>
</html>