<%-- 
    Document   : Notifications
    Created on : Nov 30, 2024, 9:51:21 PM
    Author     : yuand
--%>

<%@ page contentType="text/html; charset=UTF-8" %>

<c:forEach var="notification" items="${notifications}">
    <p>${notification.message}</p>
</c:forEach>
