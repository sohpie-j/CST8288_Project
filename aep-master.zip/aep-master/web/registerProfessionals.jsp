<!DOCTYPE html>
<html>
<head>
    <title>Register Academic Professional</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
        }
        h1 {
            color: #4CAF50;
        }
        form {
            max-width: 500px;
            margin: auto;
        }
        label {
            font-weight: bold;
        }
        input[type="text"], input[type="email"], input[type="password"] {
            width: 100%;
            padding: 10px;
            margin: 10px 0 20px 0;
            border: 1px solid #ddd;
            border-radius: 4px;
            box-sizing: border-box;
        }
        button {
            background-color: #4CAF50;
            color: white;
            padding: 10px 15px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        button:hover {
            background-color: #45a049;
        }
    </style>
</head>
<body>
    <h1>Register as an Academic Professional</h1>
    <form action="registerProfessionalServlet" method="post">
        <label>Name:</label>
        <input type="text" name="name" required><br>
        
        <label>Email:</label>
        <input type="email" name="email" required><br>
        
        <label>Password:</label>
        <input type="password" name="password" required><br>
        
        <label>Current Institution:</label>
        <input type="text" name="currentInstitution" required><br>
        
        <label>Academic Position:</label>
        <input type="text" name="academicPosition" required><br>
        
        <button type="submit">Register</button>
    </form>
</body>
</html>
