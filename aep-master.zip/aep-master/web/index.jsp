<!DOCTYPE html>
<html>
<head>
    <title>Welcome to Academic Exchange Platform</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
            text-align: center;
        }
        h1 {
            color: #4CAF50;
        }
        ul {
            list-style-type: none;
            padding: 0;
        }
        li {
            margin: 10px 0;
        }
        a {
            text-decoration: none;
            color: #4CAF50;
            font-weight: bold;
            font-size: 18px;
        }
        a:hover {
            color: #45a049;
        }
        .login-section {
            margin-top: 30px;
        }
        button {
            background-color: #4CAF50;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 4px;
            font-size: 16px;
            cursor: pointer;
        }
        button:hover {
            background-color: #45a049;
        }
    </style>
</head>
<body>
    <h1>Welcome to Academic Exchange Platform</h1>
    <p>Select an option below:</p>
    <ul>
        <li><a href="registerProfessionals.jsp">Register as Academic Professional</a></li>
        <li><a href="registerInstitution.jsp">Register as Academic Institution</a></li>
    </ul>
    <div class="login-section">
        <p>Already have an account?</p>
        <button onclick="window.location.href='login.jsp';">Login</button>
    </div>
</body>
</html>
