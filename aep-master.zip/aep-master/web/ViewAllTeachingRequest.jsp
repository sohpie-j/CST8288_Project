<%@ page import="java.util.List" %>
<%@ page import="models.TeachRequest" %>
<%@ page session="true" contentType="text/html; charset=UTF-8" %>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Course Requests</title>
    <style>
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            padding: 8px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        th {
            background-color: #f2f2f2;
        }
        .pending {
            color: orange;
        }
        .approved {
            color: green;
        }
        .rejected {
            color: red;
        }
        .reply-form {
            display: none;
            margin-top: 10px;
        }
    </style>
    <script>
        function toggleReplyForm(requestId) {
            var form = document.getElementById('replyForm_' + requestId);
            if (form.style.display === 'none' || form.style.display === '') {
                form.style.display = 'block';
            } else {
                form.style.display = 'none';
            }
        }
    </script>
</head>
<body>
    <div class="container">
        <h1>Manage Course Requests</h1>

        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Professor ID</th>
                    <th>Institution ID</th>
                    <th>Course ID</th>
                    <th>Status</th>
                    <th>Application Date</th>
                    <th>Reply Message</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <% 
                    // Retrieve the teachRequests attribute from the request
                    List<TeachRequest> teachRequests = (List<TeachRequest>) request.getAttribute("teachRequests");
                    if (teachRequests != null && !teachRequests.isEmpty()) {
                        for (TeachRequest req : teachRequests) {
                %>
                <tr>
                    <td><%= req.getId() %></td>
                    <td><%= req.getProfId() %></td>
                    <td><%= req.getInstitutionId() %></td>
                    <td><%= req.getCourseId() %></td>
                    <td class="<%= req.getStatus().toLowerCase() %>"><%= req.getStatus() %></td>
                    <td><%= req.getApplicationDate() %></td>
                    <td><%= req.getReplyMessage() != null ? req.getReplyMessage() : "" %></td>
                    <td>
                     
                        <!-- Approve request -->
                        <form action="ManageAllRequests" method="POST" style="display:inline;">
                            <input type="hidden" name="requestId" value="<%= req.getId() %>">
                            <input type="hidden" name="action" value="approve">
                            <button type="submit">Approve</button>
                        </form>

                        <!-- Reject request -->
                        <form action="ManageAllRequests" method="POST" style="display:inline;">
                            <input type="hidden" name="requestId" value="<%= req.getId() %>">
                            <input type="hidden" name="action" value="reject">
                            <button type="submit">Reject</button>
                        </form>

                  
                    </td>
                </tr>
                <% 
                        } // End for loop
                    } else { 
                %>
                <tr>
                    <td colspan="8">No course requests found.</td>
                </tr>
                <% 
                    } // End if 
                %>
            </tbody>
        </table>
    </div>
</body>
</html>
