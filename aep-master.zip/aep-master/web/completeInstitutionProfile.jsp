<%@ page contentType="text/html; charset=UTF-8" %>

<!DOCTYPE html>
<html>
<head>
    <title>Complete Institution Profile</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 0; padding: 0; text-align: center; }
        form { max-width: 400px; margin: 50px auto; padding: 20px; border: 1px solid #ddd; border-radius: 8px; }
        label { font-weight: bold; display: block; margin-top: 15px; }
        input, button { width: 100%; padding: 10px; margin: 10px 0; border: 1px solid #ddd; border-radius: 4px; }
        button { background-color: #4CAF50; color: white; cursor: pointer; }
        button:hover { background-color: #45a049; }
    </style>
</head>
<body>
    <h1>Complete Your Institution Profile</h1>
    <form action="updateInstitutionProfileServlet" method="post">
         <input type="hidden" id="email" name="email" value="${institution.email}">
        
        <label for="address">Address:</label>
    <input type="text" id="address" name="address" required>
    
    <label for="coursesOffered">Courses Offered:</label>
    <textarea id="coursesOffered" name="coursesOffered" required></textarea>
    
    <button type="submit">Submit</button>
</form>
</body>
</html>
