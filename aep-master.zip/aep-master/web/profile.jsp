<%@ page import="models.AcademicProfessional" %>
<%
    AcademicProfessional professional = (AcademicProfessional) session.getAttribute("professional");
    if (professional == null) {
        response.sendRedirect("login.jsp");
        return;
    }
%>
<!DOCTYPE html>
<html>
<head>
    <title>Your Profile</title>
</head>
<body>
    <h1>Welcome, <%= professional.getName() %></h1>
    <p><strong>Email:</strong> <%= professional.getEmail() %></p>
    <p><strong>Current Institution:</strong> <%= professional.getCurrentInstitution() %></p>
    <p><strong>Academic Position:</strong> <%= professional.getAcademicPosition() %></p>
    <p><strong>Education Background:</strong> <%= professional.getEducationBackground() %></p>
    <p><strong>Area of Expertise:</strong> <%= professional.getAreaOfExpertise() %></p>
    <a href="updateProfessionalProfile.jsp">Update Profile</a>
</body>
</html>
