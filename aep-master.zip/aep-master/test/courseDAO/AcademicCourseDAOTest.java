package courseDAO;

import dao.AcademicCourseDAO;
import models.AcademicCourse;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * Unit tests for the {@link AcademicCourseDAO} class.
 * This class tests the functionality of creating and retrieving courses
 * from the database.
 */
public class AcademicCourseDAOTest {

    /**
     * DAO instance for interacting with the Courses table.
     */
    private AcademicCourseDAO courseDAO;

    /**
     * Connection object for the in-memory database used during tests.
     */
    private Connection connection;

    /**
     * Sets up the in-memory H2 database and initializes the DAO instance.
     * This method is executed before each test.
     * 
     * @throws SQLException if a database error occurs during setup.
     */
    @Before
    public void setup() throws SQLException {
        // Establish an in-memory H2 database connection
        connection = DriverManager.getConnection("jdbc:h2:mem:testdb;DB_CLOSE_DELAY=-1", "sa", "");
        courseDAO = new AcademicCourseDAO(connection);

        // Drop the existing table if it exists
        String dropTableSQL = "DROP TABLE IF EXISTS Courses;";
        connection.createStatement().execute(dropTableSQL);

        // Create a new table for testing
        String createTableSQL = """
            CREATE TABLE Courses (
                course_id INT AUTO_INCREMENT PRIMARY KEY,
                course_code VARCHAR(50),
                course_name VARCHAR(100),
                semester VARCHAR(50),
                instructor VARCHAR(100),
                school_name VARCHAR(100),
                school_address VARCHAR(255),
                description TEXT
            );
        """;
        connection.createStatement().execute(createTableSQL);
    }

    /**
     * Tests the {@link AcademicCourseDAO#createCourse(AcademicCourse)} method.
     * Ensures that a new course can be created successfully and verifies its
     * insertion in the database.
     * 
     * @throws SQLException if a database error occurs during the test.
     */
    @Test
    public void testCreateCourse() throws SQLException {
        // Create a new course
        AcademicCourse course = new AcademicCourse("CST8288", "Java Programming", "Fall 2024",
                "John Doe", "University XYZ", "123 Main St", "Advanced Java concepts");

        // Insert the course and retrieve the generated course ID
        int courseId = courseDAO.createCourse(course);
        assertTrue("Course ID should be greater than 0 after creation", courseId > 0);

        // Verify that the course exists in the database
        var resultSet = connection.createStatement().executeQuery("SELECT * FROM Courses WHERE course_id = " + courseId);
        assertTrue("Created course should exist in the database", resultSet.next());
        assertEquals("CST8288", resultSet.getString("course_code"));
        assertEquals("Java Programming", resultSet.getString("course_name"));
    }

    /**
     * Tests the {@link AcademicCourseDAO#getCourseById(int)} method.
     * Ensures that a course can be retrieved successfully by its ID.
     * 
     * @throws SQLException if a database error occurs during the test.
     */
    @Test
    public void testGetCourseById() throws SQLException {
        // Insert a course directly into the database
        String insertSQL = """
            INSERT INTO Courses (course_code, course_name, semester, instructor, school_name, school_address, description)
            VALUES ('CST8288', 'Java Programming', 'Fall 2024', 'John Doe', 'University XYZ', '123 Main St', 'Advanced Java concepts');
        """;
        try (var preparedStatement = connection.prepareStatement(insertSQL, java.sql.Statement.RETURN_GENERATED_KEYS)) {
            preparedStatement.executeUpdate();

            // Retrieve the generated key
            try (var resultSet = preparedStatement.getGeneratedKeys()) {
                if (resultSet.next()) {
                    int courseId = resultSet.getInt(1);

                    // Use DAO to retrieve the course by its ID
                    AcademicCourse course = courseDAO.getCourseById(courseId);
                    assertNotNull("Course should not be null", course);
                    assertEquals("CST8288", course.getCourseCode());
                    assertEquals("Java Programming", course.getCourseTitle());
                } else {
                    fail("No course ID was generated.");
                }
            }
        }
    }

    /**
     * Closes the database connection after each test.
     * This method is executed after each test to clean up resources.
     * 
     * @throws SQLException if a database error occurs during teardown.
     */
    @After
    public void teardown() throws SQLException {
        if (connection != null) {
            connection.close();
        }
    }
}
