package academicDAO;

import dao.AcademicProfessionalDAO;
import models.AcademicProfessional;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * Unit tests for the {@link AcademicProfessionalDAO} class.
 * This class verifies the functionality of registering, logging in, 
 * and updating the profile of academic professionals.
 */
public class AcademicProfessionalDAOTest {

    /**
     * Connection object for the in-memory database used during tests.
     */
    private Connection connection;

    /**
     * DAO object for interacting with the academic professionals table.
     */
    private AcademicProfessionalDAO professionalDAO;

    /**
     * Sets up the in-memory H2 database and initializes the DAO instance.
     * This method is executed before each test.
     * 
     * @throws SQLException if a database error occurs during setup.
     */
    @Before
    public void setup() throws SQLException {
        // Establish an in-memory H2 database connection
        connection = DriverManager.getConnection("jdbc:h2:mem:testdb;DB_CLOSE_DELAY=-1", "sa", "");
        professionalDAO = new AcademicProfessionalDAO(connection);
        
        // Drop the existing table if it exists
        String dropTableSQL = "DROP TABLE IF EXISTS AcademicProfessional";
        connection.createStatement().execute(dropTableSQL);

        // Create a new table for testing
        String createTableSQL = """
            CREATE TABLE AcademicProfessional (
                email VARCHAR(100) PRIMARY KEY,
                name VARCHAR(100),
                password VARCHAR(100),
                currentInstitution VARCHAR(100),
                academicPosition VARCHAR(100),
                educationBackground VARCHAR(255),
                areaOfExpertise VARCHAR(255)
            );
        """;
        connection.createStatement().execute(createTableSQL);
    }

    /**
     * Tests the {@link AcademicProfessionalDAO#register(AcademicProfessional)} method.
     * Ensures that a new academic professional can be registered successfully.
     */
    @Test
    public void testRegister() {
        // Create a new academic professional
        AcademicProfessional professional = new AcademicProfessional(
            "John Doe", "john.doe@professional.com", "password123", "Test University", "Professor"
        );

        // Attempt to register the professional
        boolean isRegistered = professionalDAO.register(professional);

        // Assert that registration was successful
        assertTrue("Professional should be registered successfully", isRegistered);
    }

    /**
     * Tests the {@link AcademicProfessionalDAO#login(String, String)} method.
     * Ensures that an academic professional can log in successfully using valid credentials.
     */
    @Test
    public void testLogin() {
        // Register a new academic professional
        AcademicProfessional professional = new AcademicProfessional(
            "John Doe", "john.doe@professional.com", "password123", "Test University", "Professor"
        );
        professionalDAO.register(professional);

        // Attempt to log in with valid credentials
        AcademicProfessional loggedInProfessional = professionalDAO.login("john.doe@professional.com", "password123");

        // Assert that the login was successful and the returned object is correct
        assertNotNull("Login should return a professional object", loggedInProfessional);
        assertEquals("Professional name should match", "John Doe", loggedInProfessional.getName());
    }

    /**
     * Tests the {@link AcademicProfessionalDAO#updateProfessionalProfile(AcademicProfessional)} method.
     * Ensures that an academic professional's profile can be updated successfully.
     */
    @Test
    public void testUpdateProfile() {
        // Register a new academic professional
        AcademicProfessional professional = new AcademicProfessional(
            "John Doe", "john.doe@professional.com", "password123", "Test University", "Professor"
        );
        professionalDAO.register(professional);

        // Update the professional's profile
        professional.setEducationBackground("PhD in AI");
        professional.setAreaOfExpertise("Artificial Intelligence");
        boolean isUpdated = professionalDAO.updateProfessionalProfile(professional);

        // Assert that the update was successful
        assertTrue("Profile should be updated successfully", isUpdated);

        // Retrieve the updated profile and verify the changes
        AcademicProfessional updatedProfessional = professionalDAO.getProfessionalByEmail("john.doe@professional.com");
        assertEquals("Updated education background should match", "PhD in AI", updatedProfessional.getEducationBackground());
        assertEquals("Updated area of expertise should match", "Artificial Intelligence", updatedProfessional.getAreaOfExpertise());
    }

    /**
     * Closes the database connection after each test.
     * This method is executed after each test to clean up resources.
     * 
     * @throws SQLException if a database error occurs during teardown.
     */
    @After
    public void teardown() throws SQLException {
        connection.close();
    }
}
