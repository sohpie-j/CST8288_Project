package academicDAO;

import dao.AcademicInstitutionDAO;
import models.AcademicInstitution;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * Unit tests for the {@link AcademicInstitutionDAO} class.
 * This class verifies the functionality of the register, login, and updateInstitutionProfile methods.
 */
public class AcademicInstitutionDAOTest {

    /**
     * Database connection used for testing.
     */
    private Connection connection;

    /**
     * DAO instance for interacting with the database during tests.
     */
    private AcademicInstitutionDAO institutionDAO;

    /**
     * Sets up the in-memory database and initializes the DAO instance.
     * This method is executed before each test.
     *
     * @throws SQLException if a database error occurs.
     */
    @Before
    public void setup() throws SQLException {
        // Establish an in-memory H2 database connection
        connection = DriverManager.getConnection("jdbc:h2:mem:testdb;DB_CLOSE_DELAY=-1", "sa", "");
        institutionDAO = new AcademicInstitutionDAO(connection);

        // Drop the table if it exists
        String dropTableSQL = "DROP TABLE IF EXISTS AcademicInstitution";
        connection.createStatement().execute(dropTableSQL);

        // Create a new table for testing
        String createTableSQL = """
            CREATE TABLE AcademicInstitution (
                email VARCHAR(100) PRIMARY KEY,
                password VARCHAR(100),
                institutionName VARCHAR(100),
                address VARCHAR(255),
                coursesOffered VARCHAR(255)
            );
        """;
        connection.createStatement().execute(createTableSQL);
    }

    /**
     * Tests the {@link AcademicInstitutionDAO#register(AcademicInstitution)} method.
     * Ensures that a new academic institution can be registered successfully.
     */
    @Test
    public void testRegister() {
        // Create a new academic institution
        AcademicInstitution institution = new AcademicInstitution("test@institution.com", "password123", "Test Institution");

        // Register the institution
        boolean isRegistered = institutionDAO.register(institution);

        // Assert that registration was successful
        assertTrue("Institution should be registered successfully", isRegistered);
    }

    /**
     * Tests the {@link AcademicInstitutionDAO#login(String, String)} method.
     * Ensures that a registered academic institution can log in successfully using valid credentials.
     */
    @Test
    public void testLogin() {
        // Register a new academic institution
        AcademicInstitution institution = new AcademicInstitution("test@institution.com", "password123", "Test Institution");
        institutionDAO.register(institution);

        // Attempt to log in with valid credentials
        AcademicInstitution loggedInInstitution = institutionDAO.login("test@institution.com", "password123");

        // Assert that the login was successful
        assertNotNull("Login should return an institution object", loggedInInstitution);
        assertEquals("Institution name should match", "Test Institution", loggedInInstitution.getInstitutionName());
    }

    /**
     * Tests the {@link AcademicInstitutionDAO#updateInstitutionProfile(AcademicInstitution)} method.
     * Ensures that an academic institution's profile can be updated successfully.
     */
    @Test
    public void testUpdateProfile() {
        // Register a new academic institution
        AcademicInstitution institution = new AcademicInstitution("test@institution.com", "password123", "Test Institution");
        institutionDAO.register(institution);

        // Update the institution's profile
        institution.setAddress("123 Test St");
        institution.setCoursesOffered("Math, Science");
        boolean isUpdated = institutionDAO.updateInstitutionProfile(institution);

        // Assert that the update was successful
        assertTrue("Profile should be updated successfully", isUpdated);

        // Retrieve the updated profile and verify changes
        AcademicInstitution updatedInstitution = institutionDAO.getInstitutionByEmail("test@institution.com");
        assertEquals("Updated address should match", "123 Test St", updatedInstitution.getAddress());
        assertEquals("Updated courses should match", "Math, Science", updatedInstitution.getCoursesOffered());
    }

    /**
     * Closes the database connection after each test.
     *
     * @throws SQLException if a database error occurs.
     */
    @After
    public void teardown() throws SQLException {
        connection.close();
    }
}
