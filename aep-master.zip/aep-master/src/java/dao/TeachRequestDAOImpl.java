package dao;

import models.TeachRequest;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Logger;

public class TeachRequestDAOImpl implements TeachRequestDAO {
    private static final Logger LOGGER = Logger.getLogger(TeachRequestDAOImpl.class.getName());

    @Override
    public int saveTeachRequest(TeachRequest request) {
        int generatedId = -1;
        String sql = "INSERT INTO teach_requests (prof_id, institution_id, course_id, status, application_date) VALUES (?, ?, ?, ?, ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql, PreparedStatement.RETURN_GENERATED_KEYS)) {
            pstmt.setInt(1, request.getProfId());
            pstmt.setString(2, request.getInstitutionId());  // 修改为 setString
            pstmt.setString(3, request.getCourseId());
            pstmt.setString(4, request.getStatus());
            pstmt.setDate(5, new java.sql.Date(request.getApplicationDate().getTime()));
            pstmt.executeUpdate();

            ResultSet generatedKeys = pstmt.getGeneratedKeys();
            if (generatedKeys.next()) {
                generatedId = generatedKeys.getInt(1);
            }
        } catch (SQLException e) {
            LOGGER.severe("Error while saving teach request: " + e.getMessage());
        }
        return generatedId;
    }

  @Override
public ArrayList<TeachRequest> getAllTeachRequests() {
    ArrayList<TeachRequest> requests = new ArrayList<>();
    String sql = "SELECT * FROM teach_requests";
    try (Connection conn = DBConnection.getConnection()) {
        // 打印数据库 URL
        System.out.println("Database URL: " + conn.getMetaData().getURL());

        try (PreparedStatement pstmt = conn.prepareStatement(sql);
             ResultSet rs = pstmt.executeQuery()) {

            boolean hasData = false;
            while (rs.next()) {
                hasData = true;
                int id = rs.getInt("id");
                int profId = rs.getInt("prof_id");
                String institutionId = rs.getString("institution_id");
                String courseId = rs.getString("course_id");
                String status = rs.getString("status");
                java.sql.Date applicationDate = rs.getDate("application_date");
                String replyMessage = rs.getString("reply_message");

                System.out.println("Fetched request: " + id);
                requests.add(new TeachRequest(id, profId, institutionId, courseId, status, applicationDate, replyMessage));
            }

            if (!hasData) {
                System.out.println("No requests found in the database.");
            }
        }
    } catch (SQLException e) {
        e.printStackTrace();
    }
    return requests;
}


    @Override
    public void updateTeachRequest(int requestId, String replyMessage, String status) {
        String sql = "UPDATE teach_requests SET reply_message = ?, status = ? WHERE id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, replyMessage);
            pstmt.setString(2, status);
            pstmt.setInt(3, requestId);
            pstmt.executeUpdate();
        } catch (SQLException e) {
            LOGGER.severe("Error while updating teach request: " + e.getMessage());
        }
    }

    @Override
    public ArrayList<TeachRequest> getTeachRequestsByInstitution(String institutionId) {
        ArrayList<TeachRequest> requests = new ArrayList<>();
        String sql = "SELECT * FROM teach_requests WHERE institution_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, institutionId);  // 修改为 setString
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    int id = rs.getInt("id");
                    int profId = rs.getInt("prof_id");
                    String instId = rs.getString("institution_id");  // 修改为 String
                    String courseId = rs.getString("course_id");
                    String status = rs.getString("status");
                    java.sql.Date applicationDate = rs.getDate("application_date");
                    String replyMessage = rs.getString("reply_message");

                    requests.add(new TeachRequest(id, profId, instId, courseId, status, applicationDate, replyMessage));
                }
            }
        } catch (SQLException e) {
            LOGGER.severe("Error while fetching teach requests by institution: " + e.getMessage());
        }
        return requests;
    }

}