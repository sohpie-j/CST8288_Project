/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

/**
 *
 * @author yuand
 */

public class NotificationDAO {

    public static void sendNotification(int profId, String message, String notificationType) {
        String query = "INSERT INTO Notifications (user_id, message, notification_type) VALUES (?, ?, ?)";

        try (Connection conn = DBConnection.getConnection(); 
             PreparedStatement ps = conn.prepareStatement(query)) {
            
            ps.setInt(1, profId);              // 设置教授的用户 ID
            ps.setString(2, message);          // 设置通知消息
            ps.setString(3, notificationType); // 设置通知类型

            ps.executeUpdate();                // 执行插入操作
            System.out.println("Notification sent to professor with ID " + profId + ": " + message);
        } catch (SQLException e) {
            System.out.println("Failed to send notification to professor with ID " + profId);
            e.printStackTrace();
        }
    }
}
