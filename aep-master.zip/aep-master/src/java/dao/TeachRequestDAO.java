package dao;

import models.TeachRequest;
import java.util.ArrayList;

public interface TeachRequestDAO {
    int saveTeachRequest(TeachRequest request);
    ArrayList<TeachRequest> getAllTeachRequests();
    void updateTeachRequest(int requestId, String replyMessage, String status);
    ArrayList<TeachRequest> getTeachRequestsByInstitution(String institutionId);
}
