package dao;

import models.AcademicProfessional;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class AcademicProfessionalDAO {
    private Connection connection;

    public AcademicProfessionalDAO() throws SQLException {
        connection = DBConnection.getConnection();
    }

    public AcademicProfessionalDAO(Connection connection) {
        this.connection = connection;
    }
        
    public boolean register(AcademicProfessional professional) {
        String sql = "INSERT INTO academicprofessional (name, email, password, currentInstitution, academicPosition) VALUES (?, ?, ?, ?, ?)";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, professional.getName());
            stmt.setString(2, professional.getEmail());
            stmt.setString(3, professional.getPassword());
            stmt.setString(4, professional.getCurrentInstitution());
            stmt.setString(5, professional.getAcademicPosition());
            stmt.executeUpdate();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

   public AcademicProfessional login(String email, String password) {
    String sql = "SELECT * FROM AcademicProfessional WHERE email = ? AND password = ?";
    try (PreparedStatement stmt = connection.prepareStatement(sql)) {
        stmt.setString(1, email);
        stmt.setString(2, password);
        ResultSet rs = stmt.executeQuery();
        if (rs.next()) {
            return new AcademicProfessional(
                rs.getString("name"),
                rs.getString("email"),
                rs.getString("password"),
                rs.getString("currentInstitution"),
                rs.getString("academicPosition")
            );
        }
    } catch (SQLException e) {
        e.printStackTrace();
    }
    return null;
}

    public boolean updateProfessionalProfile(AcademicProfessional professional) {
    String sql = "UPDATE academicprofessional SET educationBackground = ?, areaOfExpertise = ? WHERE email = ?";
    try (PreparedStatement stmt = connection.prepareStatement(sql)) {
        stmt.setString(1, professional.getEducationBackground());
        stmt.setString(2, professional.getAreaOfExpertise());
        stmt.setString(3, professional.getEmail());
        stmt.executeUpdate();
        return true;
    } catch (SQLException e) {
        e.printStackTrace();
        return false;
    }
}

    public AcademicProfessional getProfessionalByEmail(String email) {
        String sql = "SELECT * FROM AcademicProfessional WHERE email = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, email);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return new AcademicProfessional(
                    rs.getString("name"),
                    rs.getString("email"),
                    rs.getString("password"),
                    rs.getString("currentInstitution"),
                    rs.getString("academicPosition"),
                    rs.getString("educationBackground"),
                    rs.getString("areaOfExpertise")
                );
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }
}
