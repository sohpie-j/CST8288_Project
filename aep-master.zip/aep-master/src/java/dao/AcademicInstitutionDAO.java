/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

/**
 *
 * @author Mengting Tang
 */


import models.AcademicInstitution;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class AcademicInstitutionDAO {
    private Connection connection;

    public AcademicInstitutionDAO() throws SQLException {
        connection = DBConnection.getConnection();
    }

    public AcademicInstitutionDAO(Connection connection) {
        this.connection = connection;
    }

    //  Academic Institution
    public boolean register(AcademicInstitution institution) {
        String sql = "INSERT INTO AcademicInstitution (email, password, institutionName) VALUES (?, ?, ?)";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, institution.getEmail());
            stmt.setString(2, institution.getPassword());
            stmt.setString(3, institution.getInstitutionName());
            stmt.executeUpdate();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

   public AcademicInstitution login(String email, String password) {
    String sql = "SELECT * FROM AcademicInstitution WHERE email = ? AND password = ?";
    try (PreparedStatement stmt = connection.prepareStatement(sql)) {
        stmt.setString(1, email);
        stmt.setString(2, password);
        ResultSet rs = stmt.executeQuery();
        if (rs.next()) {
            return new AcademicInstitution(
                rs.getString("email"),
                rs.getString("password"),
                rs.getString("institutionName"),
                rs.getString("address"),
                rs.getString("coursesOffered")
            );
        }
    } catch (SQLException e) {
        e.printStackTrace();
    }
    return null;
}


    // uodate Academic Institution 
    public boolean updateInstitutionProfile(AcademicInstitution institution) {
        String sql = "UPDATE AcademicInstitution SET address = ?, coursesOffered = ? WHERE email = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, institution.getAddress());
            stmt.setString(2, institution.getCoursesOffered());
            stmt.setString(3, institution.getEmail());
            stmt.executeUpdate();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
    public AcademicInstitution getInstitutionByEmail(String email) {
    String sql = "SELECT * FROM AcademicInstitution WHERE email = ?";
    try (PreparedStatement stmt = connection.prepareStatement(sql)) {
        stmt.setString(1, email);
        ResultSet rs = stmt.executeQuery();
        if (rs.next()) {
            return new AcademicInstitution(
                rs.getString("email"),
                rs.getString("password"),
                rs.getString("institutionName"),
                rs.getString("address"),
                rs.getString("coursesOffered")
            );
        }
    } catch (SQLException e) {
        e.printStackTrace();
    }
    return null;
}

}
