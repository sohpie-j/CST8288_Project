package dao;

import java.io.IOException;
import models.AcademicCourse;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class AcademicCourseDAO {

    private final Connection connection;


    //for Servelt
  
    public AcademicCourseDAO() throws SQLException {
        connection = DBConnection.getConnection();
    }
    
    //for Test
    public AcademicCourseDAO(Connection connection) {
        this.connection = connection;
    }


    public int createCourse(AcademicCourse course) throws SQLException {
        String sql = "INSERT INTO Courses (course_code, course_name, semester, instructor, school_name, school_address, description) " +
                     "VALUES (?, ?, ?, ?, ?, ?, ?)";
        try (PreparedStatement stmt = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            stmt.setString(1, course.getCourseCode());
            stmt.setString(2, course.getCourseTitle());
            stmt.setString(3, course.getSemester()); // Changed from getSemester) to getSemester()
            stmt.setString(4, course.getInstructor());
            stmt.setString(5, course.getInstitutionName());
            stmt.setString(6, course.getSchoolAddress());
            stmt.setString(7, course.getDescription());

            // Execute the update
            int affectedRows = stmt.executeUpdate();
            if (affectedRows == 0) {
                throw new SQLException("Creating course failed, no rows affected.");
            }

            // Retrieve the generated keys
            try (ResultSet generatedKeys = stmt.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    return generatedKeys.getInt(1); // Return the auto-generated course_id
                } else {
                    throw new SQLException("Creating course failed, no ID obtained.");
                }
            }
        }
    }

    public AcademicCourse getCourseById(int courseId) throws SQLException {
        String sql = "SELECT * FROM Courses WHERE course_id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, courseId);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return new AcademicCourse(
                        rs.getInt("course_id"),
                        rs.getString("course_code"),
                        rs.getString("course_name"),
                        rs.getString("semester"),
                        rs.getString("instructor"),
                        rs.getString("school_name"),
                        rs.getString("school_address"),
                        rs.getString("description")
                    );
                }
            }
        }
        return null;
    }

    public void updateCourse(AcademicCourse course) throws SQLException {
        String sql = "UPDATE Courses SET course_code = ?, course_name = ?, semester = ?, instructor = ?, " +
                     "school_name = ?, school_address = ?, description = ? WHERE course_id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, course.getCourseCode());
            stmt.setString(2, course.getCourseTitle());
            stmt.setString(3, course.getSemester());
            stmt.setString(4, course.getInstructor());
            stmt.setString(5, course.getInstitutionName());
            stmt.setString(6, course.getSchoolAddress());
            stmt.setString(7, course.getDescription());
            stmt.setInt(8, course.getId());
            int rowsAffected = stmt.executeUpdate();
            
            // Check if any rows were updated
            if (rowsAffected == 0) {
                throw new SQLException("Update failed: No rows affected.");
            }
        }
    }

    public void deleteCourse(int courseId) throws SQLException {
        String sql = "DELETE FROM Courses WHERE course_id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, courseId);
            stmt.executeUpdate();
        }
    }

    public List<AcademicCourse> searchCourses(String searchCriteria, String searchValue) throws SQLException {
        // SQL Injection 방지를 위해 searchCriteria 값을 제한적으로 허용
        if (!"course_code".equals(searchCriteria) &&
            !"course_name".equals(searchCriteria) &&
            !"school_name".equals(searchCriteria) &&
            !"semester".equals(searchCriteria)) {
            throw new SQLException("Invalid search criteria.");
        }

        String sql = "SELECT * FROM Courses WHERE " + searchCriteria + " LIKE ?";
        List<AcademicCourse> courses = new ArrayList<>();

        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, "%" + searchValue + "%");
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                courses.add(new AcademicCourse(
                    rs.getString("course_code"),
                    rs.getString("course_name"),
                    rs.getString("semester"),
                    rs.getString("instructor"),
                    rs.getString("school_name"),
                    rs.getString("school_address"),
                    rs.getString("description")
                ));
            }
        }
        return courses;
    }
}
