
package servlets;

import dao.AcademicInstitutionDAO;
import dao.AcademicProfessionalDAO;
import models.AcademicInstitution;
import models.AcademicProfessional;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

@WebServlet(name = "profileServlet", urlPatterns = {"/profileServlet"})
public class ProfileServlet extends HttpServlet {
    private AcademicInstitutionDAO institutionDAO;
    private AcademicProfessionalDAO professionalDAO;

    @Override
    public void init() {
        try {
            try {
                institutionDAO = new AcademicInstitutionDAO();
            } catch (SQLException ex) {
                Logger.getLogger(ProfileServlet.class.getName()).log(Level.SEVERE, null, ex);
            }
            professionalDAO = new AcademicProfessionalDAO();
        } catch (SQLException ex) {
            Logger.getLogger(ProfileServlet.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession(false);

        if (session == null || session.getAttribute("user") == null) {
            response.sendRedirect("login.jsp");
            return;
        }

        Object user = session.getAttribute("user");

        if (user instanceof AcademicProfessional) {
            handleProfessionalProfile(request, response, (AcademicProfessional) user, session);
        } else if (user instanceof AcademicInstitution) {
            handleInstitutionProfile(request, response, (AcademicInstitution) user, session);
        } else {
            response.sendRedirect("login.jsp");
        }
    }

    private void handleProfessionalProfile(HttpServletRequest request, HttpServletResponse response,
                                           AcademicProfessional professional, HttpSession session) throws ServletException, IOException {
        AcademicProfessional refreshedProfessional = professionalDAO.getProfessionalByEmail(professional.getEmail());

        if (refreshedProfessional != null) {
            session.setAttribute("user", refreshedProfessional);

           
            if (refreshedProfessional.getEducationBackground() == null || refreshedProfessional.getAreaOfExpertise() == null) {
                request.setAttribute("professional", refreshedProfessional);
                request.getRequestDispatcher("completeProfessionalProfile.jsp").forward(request, response);
            } else {
                request.setAttribute("professional", refreshedProfessional);
                request.getRequestDispatcher("professionalProfile.jsp").forward(request, response);
            }
        } else {
            response.getWriter().println("Failed to load professional profile information.");
        }
    }

    private void handleInstitutionProfile(HttpServletRequest request, HttpServletResponse response,
                                          AcademicInstitution institution, HttpSession session) throws ServletException, IOException {
        AcademicInstitution refreshedInstitution = institutionDAO.getInstitutionByEmail(institution.getEmail());

        if (refreshedInstitution != null) {
            session.setAttribute("user", refreshedInstitution);

            if (refreshedInstitution.getAddress() == null || refreshedInstitution.getCoursesOffered() == null) {
                request.setAttribute("institution", refreshedInstitution);
                request.getRequestDispatcher("completeInstitutionProfile.jsp").forward(request, response);
            } else {
                request.setAttribute("institution", refreshedInstitution);
                request.getRequestDispatcher("institutionProfile.jsp").forward(request, response);
            }
        } else {
            response.getWriter().println("Failed to load institution profile information.");
        }
    }
}


