package servlets;

import dao.AcademicInstitutionDAO;
import models.AcademicInstitution;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

@WebServlet(name = "registerInstitutionServlet", urlPatterns = {"/registerInstitutionServlet"})
public class RegisterInstitutionServlet extends HttpServlet {
    public AcademicInstitutionDAO institutionDAO;

    @Override
    public void init() {
        try {
            institutionDAO = new AcademicInstitutionDAO();
        } catch (SQLException ex) {
            Logger.getLogger(RegisterInstitutionServlet.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String email = request.getParameter("email");
        String password = request.getParameter("password");
        String institutionName = request.getParameter("institutionName");

       
        AcademicInstitution institution = new AcademicInstitution(email, password, institutionName);

     
        boolean success = institutionDAO.register(institution);

        if (success) {
    
            if (institution.getAddress() == null || institution.getCoursesOffered() == null) {
                HttpSession session = request.getSession();
                session.setAttribute("user", institution);
                response.sendRedirect("completeInstitutionProfile.jsp"); 
            } else {
                response.sendRedirect("dashboard.jsp"); 
            }
        } else {
            response.getWriter().println("Registration failed. Try again.");
        }
    }
}
