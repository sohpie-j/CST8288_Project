/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package servlets;

import dao.TeachRequestDAO;
import dao.TeachRequestDAOImpl;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import models.TeachRequest;

/**
 *
 * @author yuand
 */

@WebServlet(name = "submitTeachRequestServlet", urlPatterns = {"/submitTeachRequest"})
public class SubmitTeachRequestServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private TeachRequestDAO teachRequestDAO = new TeachRequestDAOImpl();

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
            // 获取表单参数
            int profId = Integer.parseInt(request.getParameter("profId"));
            String institutionId = request.getParameter("institutionId"); // 假设为字符串类型
            String courseId = request.getParameter("courseId");
            String message = request.getParameter("message");

            // 创建 TeachRequest 对象
            TeachRequest teachRequest = new TeachRequest(0, profId, institutionId, courseId, "Pending", new Date(), message);

            // 存储到数据库
            int requestId = teachRequestDAO.saveTeachRequest(teachRequest);

            // 设置成功消息并转发到确认页面
            request.setAttribute("successMessage", "Your application has been submitted successfully.");
            request.setAttribute("requestId", requestId); // 如果需要在JSP中显示RequestId

            getServletContext().getRequestDispatcher("/requestSubmitted.jsp").forward(request, response);
        } catch (NumberFormatException e) {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Invalid input format for Professor ID or Institution ID.");
        } catch (Exception e) {
            // 捕获其他异常并记录日志
            e.printStackTrace();
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "An error occurred while processing your request.");
        }
    }
}