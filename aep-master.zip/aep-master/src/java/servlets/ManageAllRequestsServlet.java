package servlets;

import dao.TeachRequestDAO;
import dao.TeachRequestDAOImpl;
import models.TeachRequest;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;

@WebServlet("/ManageAllRequests")
public class ManageAllRequestsServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private TeachRequestDAO teachRequestDAO = new TeachRequestDAOImpl();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Fetch all teach requests
        ArrayList<TeachRequest> teachRequests = teachRequestDAO.getAllTeachRequests();
        System.out.println("Number of teach requests fetched: " + teachRequests.size()); // Debugging info
        
        request.setAttribute("teachRequests", teachRequests);
        
        ///        getServletContext().getRequestDispatcher("/ViewAllRequests.jsp").forward(request, response);
        getServletContext().getRequestDispatcher("/ViewAllTeachingRequest.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");
        int requestId = Integer.parseInt(request.getParameter("requestId"));
         System.out.println("Hello World"+ action);
        switch (action) {
            case "approve":
                teachRequestDAO.updateTeachRequest(requestId, "Approved by admin.", "Approved");
                break;
            case "reject":
                teachRequestDAO.updateTeachRequest(requestId, "Rejected by admin.", "Rejected");
                break;
            case "reply":
                String replyMessage = request.getParameter("replyMessage");
                String status = request.getParameter("status");
                teachRequestDAO.updateTeachRequest(requestId, replyMessage, status);
                break;
            default:
                // If no matching action, redirect back to the management page
                response.sendRedirect("ViewAllTeachingRequest.jsp");
                return;
        }
        ArrayList<TeachRequest> teachRequests = teachRequestDAO.getAllTeachRequests();
        System.out.println("Number of teach requests fetched: " + teachRequests.size()); // Debugging info
        
        request.setAttribute("teachRequests", teachRequests);
        getServletContext().getRequestDispatcher("/ViewAllTeachingRequest.jsp").forward(request, response);
      

        // After update, reload the page
        //response.sendRedirect("ViewAllTeachingRequest.jsp");
    }
}
