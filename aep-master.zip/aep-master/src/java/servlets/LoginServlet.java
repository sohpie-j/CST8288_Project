package servlets;

import dao.AcademicProfessionalDAO;
import dao.AcademicInstitutionDAO;
import models.AcademicProfessional;
import models.AcademicInstitution;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

@WebServlet(name = "loginServlet", urlPatterns = {"/loginServlet"})
public class LoginServlet extends HttpServlet {
    private AcademicProfessionalDAO professionalDAO;
    private AcademicInstitutionDAO institutionDAO;

    @Override
    public void init() {
        try {
            professionalDAO = new AcademicProfessionalDAO();
        } catch (SQLException ex) {
            Logger.getLogger(LoginServlet.class.getName()).log(Level.SEVERE, null, ex);
        }
        try {
            institutionDAO = new AcademicInstitutionDAO();
        } catch (SQLException ex) {
            Logger.getLogger(LoginServlet.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String email = request.getParameter("email");
        String password = request.getParameter("password");

        HttpSession session = request.getSession();

        try {
            // Check if the user is an Academic Professional
            AcademicProfessional professional = professionalDAO.login(email, password);
            if (professional != null) {
                session.setAttribute("userType", "professional");
                session.setAttribute("user", professional);
                session.setAttribute("isAcademicProfessional", true); // Set to true for Academic Professional
                session.setAttribute("isAcademicInstitution", false);
                response.sendRedirect("dashboard.jsp");
                return; // Stop further processing
            }

            // Check if the user is an Academic Institution
            AcademicInstitution institution = institutionDAO.login(email, password);
            if (institution != null) {
                session.setAttribute("userType", "institution");
                session.setAttribute("user", institution);
                session.setAttribute("isAcademicProfessional", false);
                session.setAttribute("isAcademicInstitution", true); // Set to false for Academic Institution
                response.sendRedirect("dashboard.jsp");
                return; // Stop further processing
            }

            // If login fails
            response.setContentType("text/html");
            response.getWriter().println("<html><body>");
            response.getWriter().println("<h3>Invalid email or password. Please try again.</h3>");
            response.getWriter().println("<a href='login.jsp'>Go Back to Login</a>");
            response.getWriter().println("</body></html>");

        } catch (Exception e) {
            throw new ServletException("Error during login process", e);
        }
    }
}
