package servlets;

import dao.AcademicProfessionalDAO;
import models.AcademicProfessional;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

@WebServlet(name = "registerProfessionalServlet", urlPatterns = {"/registerProfessionalServlet"})
public class RegisterProfessionalServlet extends HttpServlet {
    public AcademicProfessionalDAO professionalDAO;

    @Override
    public void init() {
        try {
            professionalDAO = new AcademicProfessionalDAO();
        } catch (SQLException ex) {
            Logger.getLogger(RegisterProfessionalServlet.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String name = request.getParameter("name");
        String email = request.getParameter("email");
        String password = request.getParameter("password");
        String institution = request.getParameter("currentInstitution");
        String position = request.getParameter("academicPosition");
        String idString = request.getParameter("id");
        int id = (idString != null && !idString.isEmpty()) ? Integer.parseInt(idString) : 0; 

        AcademicProfessional professional = new AcademicProfessional(name, email, password, institution, position);
        boolean success = professionalDAO.register(professional);

        if (success) {
          
            HttpSession session = request.getSession();
            session.setAttribute("user", professional); 
            session.setAttribute("isAcademicProfessional", true);

        
            if (professional.getEducationBackground() == null || professional.getAreaOfExpertise() == null) {
                response.sendRedirect("completeProfessionalProfile.jsp"); 
            } else {
                response.sendRedirect("dashboard.jsp");
            }
        } else {
            response.getWriter().println("Registration failed. Please try again.");
        }
    }
}
