package servlets;



import dao.TeachRequestDAO;
import dao.TeachRequestDAOImpl;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(name = "replyServlet", urlPatterns = {"/replyServlet"})
public class replyServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private TeachRequestDAO teachRequestDAO = new TeachRequestDAOImpl();

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String requestIdStr = request.getParameter("requestId");
        String replyMessage = request.getParameter("replyMessage");
        String status = request.getParameter("status");

        // Log received parameters for debugging
        System.out.println("Received Parameters:");
        System.out.println("requestId: " + requestIdStr);
        System.out.println("replyMessage: " + replyMessage);
        System.out.println("status: " + status);

        // Validate parameters
        if (requestIdStr == null || requestIdStr.trim().isEmpty() ||
            replyMessage == null || replyMessage.trim().isEmpty() ||
            status == null || status.trim().isEmpty()) {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Missing required parameters.");
            return;
        }

        try {
            int requestId = Integer.parseInt(requestIdStr);
            teachRequestDAO.updateTeachRequest(requestId, replyMessage, status);
        } catch (NumberFormatException e) {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Invalid request ID format.");
            return;
        }

        // Redirect back to the management page
        response.sendRedirect("manageRequests");
    }
}



