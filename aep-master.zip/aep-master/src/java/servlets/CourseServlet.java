package servlets;

import dao.AcademicCourseDAO;
import models.AcademicCourse;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

@WebServlet(name = "courseServlet", urlPatterns = {"/CourseServlet"})
public class CourseServlet extends HttpServlet {
    private AcademicCourseDAO courseDAO;

    private static final String ACTION_CREATE = "create";
    private static final String ACTION_EDIT = "edit";
    private static final String ACTION_UPDATE = "update";
    private static final String ACTION_DELETE = "delete";
    private static final String ACTION_SEARCH = "search";

    @Override
    public void init() {
        try {
            courseDAO = new AcademicCourseDAO(); // Initialize DAO
        } catch (SQLException ex) {
            Logger.getLogger(CourseServlet.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getParameter("action");

        try {
            switch (action) {
                case ACTION_CREATE:
                    createCourse(request, response);
                    break;
                case ACTION_EDIT:
                    editCourse(request, response);
                    break;
                case ACTION_UPDATE:
                    updateCourse(request, response);
                    break;
                case ACTION_DELETE:
                    deleteCourse(request, response);
                    break;
                default:
                    response.sendRedirect("error.jsp");
                    break;
            }
        } catch (SQLException e) {
            handleError(response, "Database error occurred: " + e.getMessage());
        } catch (Exception e) {
            handleError(response, "Unexpected error: " + e.getMessage());
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getParameter("action");

        try {
            if (ACTION_SEARCH.equals(action)) {
                searchCourses(request, response);
            } else {
                response.sendRedirect("error.jsp");
            }
        } catch (SQLException e) {
            handleError(response, "Database error occurred: " + e.getMessage());
        }
    }

    private void createCourse(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException, ServletException {
        AcademicCourse course = new AcademicCourse();
        course.setCourseCode(request.getParameter("courseCode"));
        course.setCourseTitle(request.getParameter("courseName")); // Fixed key to match "courseName"
        course.setSemester(request.getParameter("semester")); // Fixed key to match "semester"
        course.setInstructor(request.getParameter("instructor"));
        course.setInstitutionName(request.getParameter("schoolName")); // Fixed key to match "schoolName"
        course.setSchoolAddress(request.getParameter("schoolAddress"));
        course.setDescription(request.getParameter("description"));

        // Validate required parameters
        if (course.getCourseCode() == null || course.getCourseTitle() == null) {
            handleError(response, "Course Code and Name are required.");
            return;
        }

        // Create course in the database
        int courseId = courseDAO.createCourse(course);

        // Fetch the created course details to display
        AcademicCourse createdCourse = courseDAO.getCourseById(courseId);

        if (createdCourse != null) {
            request.setAttribute("course", createdCourse);
            request.getRequestDispatcher("courseDetails.jsp").forward(request, response);
        } else {
            handleError(response, "Error: Unable to retrieve created course details.");
        }
    }


    
    private void editCourse(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException, ServletException {
        int courseId = Integer.parseInt(request.getParameter("courseId"));
        AcademicCourse course = courseDAO.getCourseById(courseId);

        if (course != null) {
            request.setAttribute("course", course);
            request.getRequestDispatcher("courseUpdate.jsp").forward(request, response);
        } else {
            handleError(response, "Error: Course not found.");
        }
    }

//    private void updateCourse(HttpServletRequest request, HttpServletResponse response)
//            throws SQLException, IOException, ServletException {
//        int courseId = Integer.parseInt(request.getParameter("courseId"));
//        AcademicCourse course = new AcademicCourse();
//        course.setId(courseId);
//        course.setCourseCode(request.getParameter("courseCode"));
//        course.setCourseTitle(request.getParameter("courseTitle"));
//        course.setSemester(request.getParameter("semester"));
//        course.setInstructor(request.getParameter("instructor"));
//        course.setInstitutionName(request.getParameter("institutionName"));
//        course.setSchoolAddress(request.getParameter("schoolAddress"));
//        course.setDescription(request.getParameter("description"));
//
//        courseDAO.updateCourse(course);
//
//        // Fetch updated course details
//        AcademicCourse updatedCourse = courseDAO.getCourseById(courseId);
//
//        if (updatedCourse != null) {
//            // Forward to courseDetails.jsp
//            request.setAttribute("course", updatedCourse);
//            request.getRequestDispatcher("courseDetails.jsp").forward(request, response);
//        } else {
//            // Handle error if the course is not found
//            response.getWriter().println("Error: Unable to fetch updated course details.");
//        }
//    }

    private void updateCourse(HttpServletRequest request, HttpServletResponse response)
        throws SQLException, IOException, ServletException {
        int courseId = Integer.parseInt(request.getParameter("courseId"));
        AcademicCourse course = new AcademicCourse();

        // Populate course object with updated values
        course.setId(courseId);
        course.setCourseCode(request.getParameter("courseCode"));
        course.setCourseTitle(request.getParameter("courseName"));
        course.setSemester(request.getParameter("semester"));
        course.setInstructor(request.getParameter("instructor"));
        course.setInstitutionName(request.getParameter("schoolName"));
        course.setSchoolAddress(request.getParameter("schoolAddress"));
        course.setDescription(request.getParameter("description"));

        // Update the course in the database
        courseDAO.updateCourse(course);

        // Fetch the updated course
        AcademicCourse updatedCourse = courseDAO.getCourseById(courseId);

        if (updatedCourse != null) {
            request.setAttribute("course", updatedCourse);
            request.getRequestDispatcher("courseDetails.jsp").forward(request, response);
        } else {
            response.getWriter().println("Error: Unable to fetch updated course details.");
        }
    }
        private void deleteCourse(HttpServletRequest request, HttpServletResponse response)
                throws SQLException, IOException {
            int courseId = Integer.parseInt(request.getParameter("courseId"));
            courseDAO.deleteCourse(courseId);
            response.sendRedirect("courseCreate.jsp?message=Course deleted successfully");
    }

private void searchCourses(HttpServletRequest request, HttpServletResponse response)
        throws SQLException, IOException, ServletException {
    String searchCriteria = request.getParameter("searchCriteria"); // 검색 기준 (e.g., "course_code")
    String searchValue = request.getParameter("searchValue");       // 검색 값 (e.g., "CST8288")

    if (searchCriteria == null || searchValue == null) {
        request.setAttribute("message", "Invalid search criteria or value.");
        request.getRequestDispatcher("courseSearchResults.jsp").forward(request, response);
        return;
    }

    // DAO 호출
    List<AcademicCourse> courses = courseDAO.searchCourses(searchCriteria, searchValue);

    // 결과 처리
    if (courses != null && !courses.isEmpty()) {
        request.setAttribute("searchResults", courses);
        request.setAttribute("message", "Search results found.");
    } else {
        request.setAttribute("message", "No courses found matching the search criteria.");
    }
    request.getRequestDispatcher("courseSearchResults.jsp").forward(request, response);
}


    private void handleError(HttpServletResponse response, String errorMessage) throws IOException {
        response.setContentType("text/html");
        response.getWriter().println("<h1>" + errorMessage + "</h1>");
    }
}