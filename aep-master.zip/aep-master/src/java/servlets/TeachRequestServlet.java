package servlets;

import models.TeachRequest;
import dao.TeachRequestDAO;
import dao.TeachRequestDAOImpl;

import java.io.IOException;
import java.util.Date;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.logging.Logger;

@WebServlet(name = "TeachRequestServlet", urlPatterns = {"/TeachRequestServlet"})
public class TeachRequestServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private static final Logger logger = Logger.getLogger(TeachRequestServlet.class.getName());
    private TeachRequestDAO teachRequestDAO = new TeachRequestDAOImpl();

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");

        try {
            if ("submit".equals(action)) {
                handleSubmit(request, response);
            } else if ("approve".equals(action) || "reject".equals(action)) {
                handleApprovalOrRejection(request, response);
            } else {
                response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Invalid action.");
            }
        } catch (Exception e) {
            logger.severe("Error processing request: " + e.getMessage());
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "An error occurred while processing your request.");
        }
    }

    private void handleSubmit(HttpServletRequest request, HttpServletResponse response) throws IOException {
        try {
            int profId = Integer.parseInt(request.getParameter("profId"));
            String institutionId = request.getParameter("institutionId");
            String courseId = request.getParameter("courseId");

            TeachRequest teachRequest = new TeachRequest(0, profId, institutionId, courseId, "Pending", new Date(), "");
            int requestId = teachRequestDAO.saveTeachRequest(teachRequest);

            // Redirect to confirmation page
            response.sendRedirect("requestSubmitted.jsp?requestId=" + requestId);
        } catch (NumberFormatException e) {
            logger.warning("Invalid input format for Professor ID: " + e.getMessage());
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Invalid input format for Professor ID.");
        }
    }

    private void handleApprovalOrRejection(HttpServletRequest request, HttpServletResponse response) throws IOException {
        try {
            int requestId = Integer.parseInt(request.getParameter("requestId"));
            String action = request.getParameter("action");

            if ("approve".equals(action)) {
                teachRequestDAO.updateTeachRequest(requestId, "Approved", "Congratulations!");
                logger.info("Request ID " + requestId + " approved.");
            } else if ("reject".equals(action)) {
                String rejectionReason = request.getParameter("rejectionReason");
                teachRequestDAO.updateTeachRequest(requestId, "Rejected", rejectionReason != null ? rejectionReason : "Rejected by Admin");
                logger.info("Request ID " + requestId + " rejected with reason: " + rejectionReason);
            }

            response.sendRedirect("manageRequests.jsp");
        } catch (NumberFormatException e) {
            logger.warning("Invalid Request ID: " + e.getMessage());
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Invalid Request ID.");
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");

        if ("viewRequests".equals(action)) {
            List<TeachRequest> requests = teachRequestDAO.getAllTeachRequests();
            request.setAttribute("teachRequests", requests);
            request.getRequestDispatcher("manageRequests.jsp").forward(request, response);
        } else {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Invalid action.");
        }
    }
}
