
package servlets;

import dao.AcademicProfessionalDAO;
import models.AcademicProfessional;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

@WebServlet(name = "updateProfessionalProfileServlet", urlPatterns = {"/updateProfessionalProfileServlet"})
public class UpdateProfessionalProfileServlet extends HttpServlet {
    private AcademicProfessionalDAO professionalDAO;

    @Override
    public void init() {
        try {
            professionalDAO = new AcademicProfessionalDAO();
        } catch (SQLException ex) {
            Logger.getLogger(UpdateProfessionalProfileServlet.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession(false);

        if (session == null || session.getAttribute("user") == null) {
            response.sendRedirect("login.jsp");
            return;
        }

    
        AcademicProfessional professional = (AcademicProfessional) session.getAttribute("user");

 
        String educationBackground = request.getParameter("educationBackground");
        String areaOfExpertise = request.getParameter("areaOfExpertise");


        professional.setEducationBackground(educationBackground);
        professional.setAreaOfExpertise(areaOfExpertise);

      
        boolean success = professionalDAO.updateProfessionalProfile(professional);

        if (success) {
            session.setAttribute("user", professional); 
            response.sendRedirect("dashboard.jsp"); 
        } else {
            response.getWriter().println("Update failed. Please try again.");
        }
    }
}



