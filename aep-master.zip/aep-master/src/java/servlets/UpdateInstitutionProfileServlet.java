package servlets;

import dao.AcademicInstitutionDAO;
import models.AcademicInstitution;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.http.HttpSession;


@WebServlet(name = "updateInstitutionProfileServlet", urlPatterns = {"/updateInstitutionProfileServlet"})
public class UpdateInstitutionProfileServlet extends HttpServlet {
    private AcademicInstitutionDAO institutionDAO;

    @Override
    public void init() {
        try {
            institutionDAO = new AcademicInstitutionDAO();
        } catch (SQLException ex) {
            Logger.getLogger(UpdateInstitutionProfileServlet.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
         HttpSession session = request.getSession(false);

        if (session == null || session.getAttribute("user") == null) {
            response.sendRedirect("login.jsp");
            return;
        }
          AcademicInstitution institution = (AcademicInstitution) session.getAttribute("user");
        
        //String email = request.getParameter("email");
        //String password = request.getParameter("password");
        String address = request.getParameter("address");
        String coursesOffered = request.getParameter("coursesOffered");

      
        //AcademicInstitution institution = new AcademicInstitution();
        //institution.setEmail(email); 
        //institution.setPassword(password);
        institution.setAddress(address);
        institution.setCoursesOffered(coursesOffered);

     
        boolean success = institutionDAO.updateInstitutionProfile(institution);

        if (success) {
            session.setAttribute("user", institution);
            response.sendRedirect("dashboard.jsp");
        } else {
            response.getWriter().println("Update failed. Please try again.");
        }
    }
}
