package models;

public class AcademicProfessional {
    private int id;
    private String name;
    private String email;
    private String password;
    private String currentInstitution;
    private String academicPosition;
    private String educationBackground;
    private String areaOfExpertise;
    private String canRequestToTeach; 

    
    public AcademicProfessional(String name, String email, String password, String currentInstitution, String academicPosition) {
        this.name = name;
        this.email = email;
        this.password = password;
        this.currentInstitution = currentInstitution;
        this.academicPosition = academicPosition;
        this.id=id;
    }

    
    public AcademicProfessional(String name, String email, String password, String currentInstitution, String academicPosition, String educationBackground, String areaOfExpertise) {
        this.name = name;
        this.email = email;
        this.password = password;
        this.currentInstitution = currentInstitution;
        this.academicPosition = academicPosition;
        this.educationBackground = educationBackground;
        this.areaOfExpertise = areaOfExpertise;
        
    }

   
    public AcademicProfessional() {
     
    }

 
    public String applyToTeach() {
      
        return "You are eligible to apply to teach.";
    }

    // Getter and Setter for Name
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    // Getter and Setter for Email
    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    // Getter and Setter for Password
    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    // Getter and Setter for Current Institution
    public String getCurrentInstitution() {
        return currentInstitution;
    }

    public void setCurrentInstitution(String currentInstitution) {
        this.currentInstitution = currentInstitution;
    }

    // Getter and Setter for Academic Position
    public String getAcademicPosition() {
        return academicPosition;
    }

    public void setAcademicPosition(String academicPosition) {
        this.academicPosition = academicPosition;
    }

    // Getter and Setter for Education Background
    public String getEducationBackground() {
        return educationBackground;
    }

    public void setEducationBackground(String educationBackground) {
        this.educationBackground = educationBackground;
    }

    // Getter and Setter for Area of Expertise
    public String getAreaOfExpertise() {
        return areaOfExpertise;
    }

    public void setAreaOfExpertise(String areaOfExpertise) {
        this.areaOfExpertise = areaOfExpertise;
    }

    // Getter and Setter for Can Request to Teach
    public String getCanRequestToTeach() {
        return canRequestToTeach;
    }

    public void setCanRequestToTeach(String canRequestToTeach) {
        this.canRequestToTeach = canRequestToTeach;
    }
}
