package models;

/**
 *
 * @author Mengting Tang
 */
public class AcademicInstitution {
    private String email;
    private String password;
    private String institutionName; 
    private String address;
    private String coursesOffered;

   
    public AcademicInstitution(String email, String password, String institutionName) {
        this.email = email;
        this.password = password;
        this.institutionName = institutionName;
    }

    
    public AcademicInstitution(String email, String password, String institutionName, String address, String coursesOffered) {
        this.email = email;
        this.password = password;
        this.institutionName = institutionName;
        this.address = address;
        this.coursesOffered = coursesOffered;
    }

    
    public AcademicInstitution() {
    }

    // getters  setters
    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getInstitutionName() {
        return institutionName;
    }

    public void setInstitutionName(String institutionName) {
        this.institutionName = institutionName;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getCoursesOffered() {
        return coursesOffered;
    }

    public void setCoursesOffered(String coursesOffered) {
        this.coursesOffered = coursesOffered;
    }
}
