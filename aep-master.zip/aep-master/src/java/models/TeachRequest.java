package models;

import java.util.Date;

public class TeachRequest {
    private int id;
    private int profId;
    private String institutionId; // 修改为String类型
    private String courseId;
    private String status;
    private Date applicationDate;
    private String replyMessage;

    // Constructor
    public TeachRequest(int id, int profId, String institutionId, String courseId, String status, Date applicationDate, String replyMessage) {
        this.id = id;
        this.profId = profId;
        this.institutionId = institutionId;
        this.courseId = courseId;
        this.status = status;
        this.applicationDate = applicationDate;
        this.replyMessage = replyMessage;
    }

    // Default constructor for Hibernate or other frameworks
    public TeachRequest() {}

    // Getters and Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getProfId() {
        return profId;
    }

    public void setProfId(int profId) {
        this.profId = profId;
    }

    public String getInstitutionId() {
        return institutionId;
    }

    public void setInstitutionId(String institutionId) {
        this.institutionId = institutionId;
    }

    public String getCourseId() {
        return courseId;
    }

    public void setCourseId(String courseId) {
        this.courseId = courseId;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Date getApplicationDate() {
        return applicationDate;
    }

    public void setApplicationDate(Date applicationDate) {
        this.applicationDate = applicationDate;
    }

    public String getReplyMessage() {
        return replyMessage;
    }

    public void setReplyMessage(String replyMessage) {
        this.replyMessage = replyMessage;
    }
}