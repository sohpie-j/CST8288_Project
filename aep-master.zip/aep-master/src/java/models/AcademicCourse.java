package models;

public class AcademicCourse {
    private int id; // Corresponds to course_id
    private String courseCode;
    private String courseTitle;
    private String semester;
    private String instructor;
    private String institutionName;
    private String schoolAddress;
    private String description;

    // Constructors
    public AcademicCourse(String courseCode, String courseTitle, String semester,
                          String instructor, String institutionName,
                          String schoolAddress, String description) {
        this.courseCode = courseCode;
        this.courseTitle = courseTitle;
        this.semester = semester;
        this.instructor = instructor;
        this.institutionName = institutionName;
        this.schoolAddress = schoolAddress;
        this.description = description;
    }
    
    public AcademicCourse(int id, String courseCode, String courseTitle, String semester,
                      String instructor, String institutionName,
                      String schoolAddress, String description) {
        this.id = id;
        this.courseCode = courseCode;
        this.courseTitle = courseTitle;
        this.semester = semester;
        this.instructor = instructor;
        this.institutionName = institutionName;
        this.schoolAddress = schoolAddress;
        this.description = description;
    }

    public AcademicCourse() {}

    // Getters and Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getCourseCode() {
        return courseCode;
    }

    public void setCourseCode(String courseCode) {
        this.courseCode = courseCode;
    }

    public String getCourseTitle() {
        return courseTitle;
    }

    public void setCourseTitle(String courseTitle) {
        this.courseTitle = courseTitle;
    }

    public String getSemester() {
        return semester;
    }

    public void setSemester(String semester) {
        this.semester = semester;
    }

    public String getInstructor() {
        return instructor;
    }

    public void setInstructor(String instructor) {
        this.instructor = instructor;
    }

    public String getInstitutionName() {
        return institutionName;
    }

    public void setInstitutionName(String institutionName) {
        this.institutionName = institutionName;
    }

    public String getSchoolAddress() {
        return schoolAddress;
    }

    public void setSchoolAddress(String schoolAddress) {
        this.schoolAddress = schoolAddress;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
    

}
