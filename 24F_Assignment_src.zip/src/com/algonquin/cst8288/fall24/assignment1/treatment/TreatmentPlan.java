package com.algonquin.cst8288.fall24.assignment1.treatment;

import com.algonquin.cst8288.fall24.assignment1.patient.Patient;

/*
* @author:KyungA Jang
* @interface: TreatmentPlan
*
*/
public interface TreatmentPlan {
    
	String createTreatmentPlan(Patient patient);
}
